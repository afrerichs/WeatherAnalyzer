class Date:
    def __init__ (self, year, month):
        self.month = month
        self.year = year

    def getYear(self):
        return self.year
    
    def getMonth(self):
        return self.month